public class DurhamAcademy {


    public static void main(String[] args) {
        Diploma d1 = new Diploma("Amelia", "physics");
        Diploma d2 = new DiplomaWithHonors("Hutch", "APCS");
        System.out.println(d1);
        System.out.println("");
        System.out.println(d2);
    }
}
