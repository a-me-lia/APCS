import java.util.ArrayList;

public class MyArrayList extends ArrayList<Integer> {
    public String toString(){
        String toReturn = super.toString().replace("[", "");
        toReturn = toReturn.replace("]", "");
        toReturn = toReturn.replaceAll(",", " ");
        return toReturn;
    }

    public static void main(String[] args) {
        MyArrayList stuff = new MyArrayList();
        stuff.add(1);
        stuff.add(4);
        stuff.add(3);
        System.out.println(stuff);
    }
}
