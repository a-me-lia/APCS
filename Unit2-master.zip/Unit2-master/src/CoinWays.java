public class CoinWays {

}
