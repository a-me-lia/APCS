import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/**
 * Randomly generates or takes s user imputed string, and searches a db for scrabble playable words.
 * @version 22.11.16
 * @author Amelia Kazcarmyk
 */

public class ScrabbleRackManager {
    private ArrayList<ArrayList <String>>database;
    private final String alpha = "abcdefghijklmnopqrstuvwxyz";
    private final int[] freq={9,2,2,4,12,2,3,2,9,1,1,4,2,6,8,2,1,6,4,6,4,2,2,1,2,1};
    private ArrayList<String> myTiles;
    private ArrayList<String> gameTiles;
    public ScrabbleRackManager(){

            database = new ArrayList<ArrayList <String>>();
            for(int i = 0; i < 26; i++){
               database.add(new ArrayList<String>());
            }
            //System.out.println("DEBUG LINE 23 " + dictionary.size());

            try{
                Scanner in = new Scanner(new File("new_scrabble.txt"));
                //Scanner in = new Scanner(new File("words_all_os.txt"));
                String word;
                while(in.hasNext()){
                    word = in.nextLine();
                    //System.out.println("DEBUG: " + word);
                    //System.out.println("DEBUG: " + alpha.indexOf(word.substring(0,1)));
                    database.get(alpha.indexOf(word.substring(0,1))).add(word);
                }
                in.close();
                for(int i = 0; i < database.size(); i++){
                    Collections.sort(database.get(i));
                }
                //for(ArrayList<String> bucket : dictionary)
                //System.out.println(bucket);
            }
            catch(Exception e){
                System.out.println("HEYHEYHEYHEY: " + e);
                e.printStackTrace();
            }

            gameTiles = new ArrayList<>();
            for(int i=0; i<freq.length; i++){
                for( int t=0; t<freq[i]; t++){
                    gameTiles.add(alpha.substring(i, i+1));
                }
            }
    }
    /** displays the contents of the player's tile rack */
    public void printRack(){
        myTiles = new ArrayList<String>();
        for(int i=0; i<7; i++){
            Collections.shuffle(gameTiles);
            myTiles.add(gameTiles.get((int)(Math.random() * gameTiles.size())));
        }
        promptUser();
        System.out.println("Letters in the rack: "+ myTiles);
    }

    public void promptUser(){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("If you would like custom tiles, please enter them below and press enter. to proceed with the random tiles, press enter");
        String v  = keyboard.nextLine();

        if(v.length()> 1){
            v.toLowerCase().replaceAll(" ","");
            myTiles.clear();
            for(int i=0; i<v.length(); i++){
                myTiles.add(v.substring(i, i+1));
            }
        }
    }
    /** builds and returns an ArrayList of String objects that are values pulled
     from
     * the dictionary/database based on the available letters in the user's tile
     * rack */
    public ArrayList<String> getPlaylist(){
        ArrayList<String> playables = new ArrayList<>();
        for(int i=0; i < 26; i++){
            if(myTiles.contains(alpha.substring(i, i+1))){
                for(String word : database.get(i)){
                    //System.out.println(word);
                    if(isPlayable(word)){
                        playables.add(word);
                        //System.out.println(word);
                    }
                }
            }
        }

        return playables;
    }
    /** print all of the playable words based on the letters in the tile rack */
    public void printMatches(){
        ArrayList<String> matches = getPlaylist();
        for(int i =0; i< matches.size(); i++){
            if((i+1) % 10 == 0){
                System.out.println();
                System.out.printf("%-14s", (matches.get(i) + ((matches.get(i).length() == 7 ? "*" : ""))));
            }
            else

                System.out.printf("%-14s", (matches.get(i) + ((matches.get(i).length() == 7 ? "*" : ""))));
        }
    }
    /** main method for the class; use only 3 command lines in main */
    public static void main(String[] args){
        ScrabbleRackManager app = new ScrabbleRackManager();
        app.printRack();
        app.printMatches();
    }

    private boolean isPlayable(String word){
        ArrayList<String> tileCopy = new ArrayList<>(myTiles);
        for(int i=0; i < word.length(); i++){
            try{
                if (tileCopy.contains(word.substring(i, i + 1)) == false) {
                    return false;
                }
                tileCopy.remove(word.substring(i, i+1));

            }
            catch (Exception e){
                return false;
            }
        }
        return true;
    }

}

