import java.util.Arrays;

public class Array extends Arrays {
    
}
