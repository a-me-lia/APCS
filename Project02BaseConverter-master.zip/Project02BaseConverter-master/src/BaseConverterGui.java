public class BaseConverterGui {
}
