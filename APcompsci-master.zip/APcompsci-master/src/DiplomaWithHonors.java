public class DiplomaWithHonors extends Diploma{
    public DiplomaWithHonors(String name, String subject) {
        super(name, subject);
    }
}
